/* See license.txt for terms of usage */

define("Firebug/CSS", ["FBL"], function(FBL) { with(FBL) {
// ********************************************************************************************* //

FBTrace.sysout("loading Mozilla::Firebug.CSS module");

// ********************************************************************************************* //
}});
