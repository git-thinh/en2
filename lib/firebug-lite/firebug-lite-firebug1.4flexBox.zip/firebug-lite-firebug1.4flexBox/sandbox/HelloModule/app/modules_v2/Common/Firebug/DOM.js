/* See license.txt for terms of usage */

define("Firebug/DOM", ["FBL"], function(FBL) { with(FBL) {
// ********************************************************************************************* //

FBTrace.sysout("loading Common::Firebug.DOM module");

// ********************************************************************************************* //
}});
